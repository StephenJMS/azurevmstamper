﻿# Create VMs from Snaps
#
Write-Host "Regenerate VM's from Snapshots for a stamp."
Write-Host "Logon, and select the appropriate subscription..."

Login-AzureRmAccount
$subscriptionId = (Get-AzureRmSubscription |Out-GridView -Title “Select an Azure Subscription …” -PassThru)
Select-AzureRmSubscription -SubscriptionId $subscriptionId.Id
#Provide the subscription Id
$subscriptionId = $subscriptionId.Id


#parameters for stamp creation
$sourcerg = "EYStampSourceRG"
$destrg = 'EYProdStampRG'

$location = 'EastUS2'
$snapsetname = "MasterSet"

#uniquie id for the stamp
$stampid = "01"
$stamptag = "Stamp" + $stampid
$stampvnetname = "StampVNet" + $stampid
$stampdiagstorename = "stampdiagstorage" + $stampid
$stamprgname = $destrg + $stampid

#vms to rebuild from snapshots
$sourcevms = 'CalcVM', 'FileQueueVM', 'FTSVM', 'StagingVM', 'StatCalcVM', 'STCVM', 'VirtualCalcVM', 'EYPOCJump'

#create the stamp location
Write-Host "Creating Stamp Resource Group: " $stamprgname
$stamprg = New-AzureRmResourceGroup -Name $stamprgname -Location $location -Tag @{Stamp=$stamptag} -Force

Write-Host "Creating Stamp VNet: " $stampvnetname
$stampsubnet = New-AzureRmVirtualNetworkSubnetConfig -Name "default" -AddressPrefix 10.0.1.0/24
$stampvnet = New-AzureRmVirtualNetwork -ResourceGroupName $stamprgname -Name $stampvnetname -AddressPrefix 10.0.1.0/24 -Location $location -Subnet $stampsubnet

Write-Host "Creating Stamp VM Diag Storage: " $stampdiagstorename
$stampdiagstore = New-AzureRmStorageAccount -ResourceGroupName $stamprgname -StorageAccountName $stampdiagstorename -Location $location -SkuName Standard_LRS -Kind Storage


#get all the snapshots from the master snapshot set
Write-Host "Extracting source VM Snapshots..."
$snapshots = Get-AzureRmSnapshot -ResourceGroupName $sourcerg


#recreate the vms from the list in parallel
# Requires invoke-parallel from https://github.com/RamblingCookieMonster/Invoke-Parallel
. ".\Invoke-Parallel.ps1"

$sourcevms | Invoke-Parallel -ImportVariables -ScriptBlock {
#foreach ($srcvm in $sourcevms) { 
#DEBUG START

    $vmname = $_
    #$vmname = $srcvm

    Write-Host "Creating Stamp VM: " $vmname
    #get the snapshot os disk for the vm - restore metadata is encoded here in tags
    $snapobj = ($snapshots | where {$_.Tags.SourceVM -eq $vmname -and $_.Tags.DiskType -eq 'OSDisk' -and $_.Tags.SET -eq $snapsetname})
    
    # create the vm 
    $vmsize = $snapobj.Tags.VMSize
    #$vmsize = "Standard_DS13_v2"
    $vm = New-AzureRmVMConfig -VMName $vmname -VMSize $vmsize

    Write-Host "Attaching OS Disk: " $snapobj.Id
    # $diskconfig = $null
    $diskconfig = New-AzureRmDiskConfig -AccountType PremiumLRS -Location $location `
                                -SourceResourceId $snapobj.Id -OSType Windows  -CreateOption Copy `
                                -DiskSizeGB $snapobj.DiskSizeGB
    Write-Host $diskconfig
    $diskname = $snapobj.Tags.SourceDisk + "_$snapsetname"
    $osdisk = New-AzureRmDisk -ResourceGroupName $stamprgname  -DiskName $diskname -Disk $diskconfig

    #Use the Managed Disk Resource Id to attach it to the virtual machine. 
    $vm = Set-AzureRmVMOSDisk -VM $vm -ManagedDiskId $osdisk.Id -CreateOption Attach -Windows 

    # Iterate through data disks
    $datasnapshots = ($snapshots | where {$_.Tags.SourceVM -eq $vmname -AND $_.Tags.DiskType -ne 'OSDisk' -AND $_.Tags.SET -eq $snapsetname})
    foreach ($datasnap in $datasnapshots) {
         Write-Host "Attaching Data Disk: " $datasnap.Id

         # $datadiskconfig = $null
         $datadiskconfig =  New-AzureRmDiskConfig -AccountType PremiumLRS -Location $location -SourceResourceId $datasnap.Id -CreateOption Copy
         Write-Host $datadiskconfig
         $diskname = $datasnap.Tags.SourceDisk + "_$snapsetname"
         $datadisk =  New-AzureRmDisk -Disk $datadiskConfig -ResourceGroupName $stamprgname -DiskName $diskname 
         
         $vm = Add-AzureRmVMDataDisk -VM $vm -Name $datadisk.Name -ManagedDiskId $datadisk.Id -Caching $datasnap.Tags.Caching -Lun $datasnap.Tags.SourceLUN -CreateOption Attach 
    }

    Set-AzureRmVMBootDiagnostics -VM $vm -Enable -ResourceGroupName $stamprgname -StorageAccountName $stampdiagstore.StorageAccountName

    #Add an (accelerated) NIC
    Write-Host "Creating VM NIC: " 
    $nicname = ($vmName).ToLower() + "sid" + $stampid + "nic"
    if ($snapobj.Tags.AccelNIC -eq "True") {
    Write-Host "Aceelerated Networking Enabled"
    $Nicobj = New-AzureRmNetworkInterface -Name $nicname -ResourceGroupName $stamprgname -Location $location `
             -SubnetId $stampvnet.Subnets[0].Id -PrivateIpAddress $snapobj.Tags.IP -EnableAcceleratedNetworking
             } else {
    Write-Host "Accelerated Networking Disabled"
    $Nicobj = New-AzureRmNetworkInterface -Name $nicname -ResourceGroupName $stamprgname -Location $location `
             -SubnetId $stampvnet.Subnets[0].Id -PrivateIpAddress $snapobj.Tags.IP
    }
    #host role
    if ($snapobj.Tags.HostRole -eq "JumpHost") {
        # add a public ipaddress for the jump host
        Write-Host "Enabling Public IP Address"
        $publicdns = "pocstamp" + $stampid + "jump"
        $publicipname = "pubip" + $stamptag
        $publicip = New-AzureRmPublicIpAddress -Name $publicipname -ResourceGroupName $stamprgname -AllocationMethod Dynamic -DomainNameLabel $publicdns -Location $location
        $Nicobj.IpConfigurations[0].PublicIpAddress = $publicip
        $nicobj = Set-AzureRmNetworkInterface -NetworkInterface $Nicobj
    }
    $vm = Add-AzureRmVMNetworkInterface -VM $vm -Id $Nicobj.Id -Primary
        
    Write-Host "VM Config..."

    #Create the VM
    New-AzureRmVM -ResourceGroupName $stamprgname -Location $location -VM $vm -DisableBginfoExtension

#DEBUG END
}
