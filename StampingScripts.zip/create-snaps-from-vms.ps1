﻿Write-Host "Create Snapshots of source VMs"
Write-Host "Logon, and select the appropriate subscription..."

Login-AzureRmAccount
$subscriptionId = (Get-AzureRmSubscription |Out-GridView -Title “Select an Azure Subscription …” -PassThru)
Select-AzureRmSubscription -SubscriptionId $subscriptionId.Id
#Provide the subscription Id
$subscriptionId = $subscriptionId.Id

# Provide the name of the stamp source resource group, snapshot dest resource group, snapshot
# resource group location, and the Name of the Snapshot to use for creating the stamp
$resourceGroupName ='EYACAPOCrg'
$destrg = 'EYStampSourceRG'
$location = 'EastUS2'
$snapsetname = "MasterSet"

# create the resource group to hold the snapshots
Write-Host "Creating Stamp Resource Group: " $destrg
$stamprg = New-AzureRmResourceGroup -Name $destrg -Location $location -Tag @{Stamp=$snapsetname} -Force

# VMs to include in the snapshots
$vmset = 'CalcVM','FileQueueVM','FTSVM','StagingVM', 'StatCalcVM', 'STCVM', 'VirtualCalcVM', 'EYPOCJump'
Write-Host "VM's included in snampshot: " $vmset
$jumpvm = 'EYPOCJump'
Write-Host "Jump VM included in snapshot: " $jumpvm


#snap the processing hosts from the defined vm set
foreach ($vmname in $vmset) {
    Write-Host "Processing VM: " $vmname

    # take snapshot OS disk
    # extract the configuration information to recreate the machine, and store in OS Disk tags
    $myvm = get-AzureRmVm -ResourceGroupName $resourceGroupName -Name $vmname
    $vmsize = $myvm.HardwareProfile.VmSize
    Write-Host "VMSize: " $vmsize 
    $nicID = $myvm.NetworkProfile.NetworkInterfaces.Id
    Write-Host "NIC Interface ID: " $nicID 
    $nicobj = Get-AzureRmNetworkInterface -ResourceGroupName $resourcegroupname | Where-Object {$_.Id -eq $nicid}
    $nicip = $nicobj.IpConfigurations.PrivateIPAddress
    Write-Host "NIC IP Address: " $nicip 
    $accelnic = $nicobj.EnableAcceleratedNetworking.ToString()
    Write-Host "Accelerated NIC: " $accelnic
    $osdiskname = $myvm.StorageProfile.OsDisk.Name
    Write-Host "OS Disk Name: " $osdiskname

    #is this the jumpvm?
    $hosttype = "ProcessingHost"
    if ($vmname -eq $jumpvm) {
        $hosttype = "JumpHost"
        }
    Write-Host "Host Type: " $hosttype

    #get the disk, and take the snapshot
    $snapshotName = $osdiskname + "_snapshot_$snapsetname"
    $disk = Get-AzureRmDisk -ResourceGroupName $resourceGroupName -DiskName $osDiskName

    $snapshot =  New-AzureRmSnapshotConfig -SourceUri $disk.Id -CreateOption Copy -Location $location `
          -Tag @{HostRole=$hosttype; SourceVM=$vmname; SourceDisk=$osdiskname; DiskType="OSDisk"; SET="$snapsetname"; `
           IP=$nicip; Caching=$myvm.StorageProfile.OsDisk.Caching.ToString(); VMSize=$vmsize; AccelNIC=$accelnic}

    New-AzureRmSnapshot -Snapshot $snapshot -SnapshotName $snapshotName -ResourceGroupName $destrg 

    Write-Host "Processing Data disks..." 
    $datadisks = $myvm.StorageProfile.DataDisks.Name
    #take snapshot of data disks
    for ($i = 0; $i -lt $datadisks.Count; $i++) {
        Write-Host "Processing Disk: " $datadisks[$i]
        $snapshotName = $datadisks[$i] + "_snapshot_$snapsetname"
        Write-Host "Snapshot disk name: " $snapshotName
        $lun = $myvm.StorageProfile.DataDisks[$i].Lun

        $datadiskobject =  Get-AzureRMDisk -ResourceGroupName $resourceGroupName -DiskName $datadisks[$i]
        $snapshot =  New-AzureRmSnapshotConfig -SourceUri $datadiskobject.Id -CreateOption Copy -Location $location `
             -Tag @{ SourceVM=$vmname; SourceDisk=$datadisks[$i]; SourceLUN="$lun"; SET="$snapsetname"; Caching=$myvm.StorageProfile.DataDisks[$i].Caching.ToString()}

        New-AzureRmSnapshot -Snapshot $snapshot -SnapshotName $snapshotName -ResourceGroupName $destrg 
        }

    Write-Host "Processing Complete for: " $vmname
}

